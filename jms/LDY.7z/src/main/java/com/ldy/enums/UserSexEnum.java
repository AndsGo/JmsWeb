package com.ldy.enums;

/**
 * Created by 80002946 on 2018/6/3.
 */
public enum UserSexEnum {
    MAN, WOMAN
}
